import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppState, DocumentData, User } from '../types';

interface AppContextType extends AppState {
  setCurrentUser: (user: User) => void;
  addDocument: (doc: DocumentData) => void;
  updateDocument: (doc: DocumentData) => void;
  deleteDocument: (id: string) => void;
}

const MOCK_USERS: User[] = [
  { id: 'user_042', name: 'Ahmed Data Entry', role: 'data_entry', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ahmed' },
  { id: 'admin_001', name: 'Fatima Admin', role: 'admin', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Fatima' },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(MOCK_USERS[0]);
  const [documents, setDocuments] = useState<DocumentData[]>([]);
  const [users] = useState<User[]>(MOCK_USERS);

  // Load from local storage on mount
  useEffect(() => {
    const savedDocs = localStorage.getItem('app_documents');
    if (savedDocs) {
      try {
        setDocuments(JSON.parse(savedDocs));
      } catch (e) {
        console.error('Failed to parse documents', e);
      }
    }
  }, []);

  // Save to local storage on change
  useEffect(() => {
    localStorage.setItem('app_documents', JSON.stringify(documents));
  }, [documents]);

  const addDocument = (doc: DocumentData) => {
    setDocuments((prev) => [...prev, doc]);
  };

  const updateDocument = (doc: DocumentData) => {
    setDocuments((prev) => prev.map((d) => (d.id === doc.id ? doc : d)));
  };

  const deleteDocument = (id: string) => {
    setDocuments((prev) => prev.filter((d) => d.id !== id));
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        documents,
        users,
        setCurrentUser,
        addDocument,
        updateDocument,
        deleteDocument,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
}
